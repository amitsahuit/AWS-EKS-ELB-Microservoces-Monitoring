# AWS EKS - Fargate Profiles

1. Fargate Profiles - Basic
2. Fargate Profiles - Advanced using YAML

## References
- https://eksctl.io/usage/fargate-support/
- https://docs.aws.amazon.com/eks/latest/userguide/fargate.html
- https://kubernetes-sigs.github.io/aws-alb-ingress-controller/guide/ingress/annotation/#target-type