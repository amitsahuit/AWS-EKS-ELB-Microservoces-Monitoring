# AWS Elastic Load Balancers

## AWS Load Balancer Types
1. Classic Load Balancer
2. Network Load Balancer
3. Application Load Balancer  (k8s Ingress)